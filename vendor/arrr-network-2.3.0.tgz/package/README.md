# arrr-network

Client SDK for the [ARRR network](https://arrr.fun) (Agentic Real-time Relay
Routing) — a mesh networking layer with WebSocket rooms, deterministic input
ordering, state sync, and cross-node replication.

Two layers, use either:

- **Transport** (`connect`): gets your inputs into a room, in order, and hands
  you back the ticks. Simulation is yours.
- **Lockstep** (`lockstep.Lockstep`): a deterministic-simulation netcode on top
  of the transport — server clock, playout delay, local prediction with
  rollback, snapshots, desync detection, reconnect, matchmaking — so a game
  implements a small `Sim` contract and draws from one clock. See
  [Netcode](#netcode-the-lockstep-layer) below.

## Install

```bash
npm install arrr-network
```

Or, in a browser, use the prebuilt IIFE bundle, which exposes the SDK as the
global `arrrNetwork`:

```html
<script src="https://arrr.fun/sdk/arrr-network.iife.js"></script>
```

## Usage

```typescript
import { connect } from 'arrr-network';

const conn = await connect('my-room', {
  appId: 'my-app',            // Required - your application ID
  apiKey: 'arrr_…',           // Your app's API key, from the portal (see below)
  user: { id: 'player1' },

  onConnect: (snapshot, events, frame) => {
    console.log('Connected at frame', frame);
  },

  onTick: (frame, events) => {
    for (const event of events) {
      console.log(`Frame ${frame}:`, event.data);
    }
  }
});

conn.send({ move: { x: 1, y: 0 } });
```

By default the SDK asks the central service at `https://cloud.arrr.fun` which
node to dial. Point `centralServiceUrl` (or `nodeUrl`, to skip discovery) at your
own deployment to run against a self-hosted mesh.

`apiKey` is the application API key minted in the portal. It is sent as
`x-api-key` when the SDK asks central for a node. A service running with
`APP_REGISTRATION=key` refuses connections without one; in the default open
mode it is optional, though a key that is unknown or belongs to another app is
refused either way. It ships in your client, so treat it as attribution and a
revocation switch, not a secret - per-user identity is `joinToken` / `authToken`.

No account yet? `curl -X POST https://cloud.arrr.fun/api/test-tier/rooms` returns
an `appId`, `apiKey` and `roomId` for one room that works for an hour (8
players, 256-byte inputs, 100 MB of traffic). See [the test tier](https://arrr.fun/test-tier).
When it ends, `connect()` rejects with a `JoinRefused` whose `code` is `room-ended`.

## API

| Export | Description |
|--------|-------------|
| `connect(roomId, options)` | Join a room; resolves to a `Connection` |
| `arrr` | Alias of `connect` |
| `listRooms(appId, options?)` | List an app's rooms with client counts |
| `getRandomRoom(appId, options?)` | Pick a room for auto-matchmaking |
| `auth` | Auth module (login, signup, session, providers) |
| `identity` / `vault` | One ARRR account per player and their saves on the mesh (see below) |
| `registerClientId(clientId)` | Register a client ID for hash lookup |
| `unregisterClientId(clientId)` | Drop a registered client ID |
| `hashClientId(clientId)` | Hash a client ID the way the wire format does |
| `encodeSyncHash(...)` / `decodeBinaryMessage(...)` | Binary protocol helpers |
| `encode(value)` / `decode(buffer)` | Codec used on the wire |
| `lockstep` | The lockstep netcode: `Lockstep`, `dialWith`, `FrameRing`, `renderTimes`, `RenderView`, `InputBeat`, `EntityPrediction`, the `fixed`/`hash`/`rng` determinism kit, `InProcessNode` - a node that runs in this process, for a game's single-player room or a test on a fake clock (`FakeNode` is its deprecated old name, removed in 4.0.0) |
| `netcode` | The model-agnostic pieces lockstep is built from: `ServerClock`, `Playout`, `Interpolation`, `Session`, `ClockView`, `Runtime`/`FakeRuntime` |
| `match` | Matchmaking over the transport: `Match` (the lobby math), `Matchmaker` (search, mint, heal a split, hand the connection to `Lockstep`) |

A `Connection` exposes `send`, `sendSnapshot`, `leaveRoom`, `close`,
`getClients`, and the `connected`, `clientId`, `frame`, `bandwidthIn`,
`bandwidthOut` properties.

Guides and examples are at [arrr.fun](https://arrr.fun); the lockstep layer's
design is in [docs/lockstep.md](https://github.com/m0dE/arrr-sdk/blob/main/docs/lockstep.md),
what a renderer must do in [docs/integration.md](https://github.com/m0dE/arrr-sdk/blob/main/docs/integration.md),
matches in [docs/match.md](https://github.com/m0dE/arrr-sdk/blob/main/docs/match.md).
This repository is
published from a private monorepo where the SDK is developed alongside the
node and the cloud service; issues and pull requests are welcome here, and
accepted changes are applied there and appear in the next publish.

## Netcode: the lockstep layer

`connect` gives you an ordered stream of inputs and a frame counter. A game
still has to know where the node's clock is, how far behind to draw other
players so a late tick is not a frozen frame, how to move its own player
before the round trip confirms it, when to snapshot, and what to do when its
world disagrees with the room's. `lockstep` owns those; the game owns a
deterministic sim.

### The sim contract

```typescript
import { lockstep } from 'arrr-network';

const sim: lockstep.Sim<State, Input> = {
  name: 'my-game',
  version: '3',                              // compared across clients; set it
  init: ({ roster, frame, seed }) => State,  // seeded only from these
  applyInput(state, input, ctx, playerId) {},
  step(state, ctx) {},                       // advance exactly one tick
  hash: (state) => uint32,                   // compared across the room
  // Optional:
  addPlayer(state, id, ctx) {},              // a join arrived in the stream
  removePlayer(state, id, ctx) {},           // a leave
  disconnectPlayer(state, id, ctx) {},       // connection gone, membership kept
  serialize: (state) => json,                // both: required for prediction and snapshots
  deserialize: (json) => State,
  fingerprint: (state, player) => string | number,   // required for prediction
  dispose(state) {},                         // free a wasm world etc.
};
```

`ctx` is `{ frame, player, roster, rng }`; `rng` is deterministic per
(room, frame). Integer or fixed-point math only (`lockstep.fixed` is Q16.16),
no `Math.random`, no `Date`, no iteration over unordered maps. Two clients
given the same inputs must produce the same `hash` every tick — that is the
whole premise, and `hash` is what the room checks it by.

`fingerprint` compares at the resolution a correction is worth: round
positions to the centimetre and velocities to match, or a physics world
rebuilt from a clone will read its own settling as a misprediction.
`ctx.roster` is frame-consistent only in `init`; track membership in the
state through `addPlayer`/`removePlayer`.

### Per frame

```typescript
const confirmed = new lockstep.FrameRing<Pose>({ depth: 64, lerp, teleportedIf });
const predicted = new lockstep.FrameRing<Pose>({ depth: 64, lerp, teleportedIf });

// The annotation is load-bearing: `inputSource` reads `ls.frame`.
const ls: lockstep.Lockstep<State, Input> = new lockstep.Lockstep<State, Input>({
  sim, player: me, room, predict: true,
  inputSource: (ctx) => currentInput(ctx?.frame ?? ls.frame + 1),   // the frame the input is AIMED at
  onConfirmedTick: (state, frame) => confirmed.record(frame, posesOf(state)),
  onPredictedTick: (state, frame) => predicted.record(frame, posesOf(state)),
  dial: lockstep.dialWith(room, { appId, apiKey, centralServiceUrl, player: me }),
});
await ls.start();

function draw() {
  requestAnimationFrame(draw);
  const t = lockstep.renderTimes(ls.view());   // null: no world yet, or a catch-up replaying
  if (!t || !ls.state) return;
  for (const id of ls.state.players.keys()) {
    if (id === me && t.drawSelfFromPrediction) continue;
    const p = confirmed.at(id, t.others);      // everyone else: confirmed ring, at the playout time
    if (p) place(id, p);
  }
  if (t.drawSelfFromPrediction) {
    const p = predicted.at(me, t.self);        // you: predicted ring, on the self clock
    if (p) place(me, p);
  }
}
```

**Everything you draw comes off one clock, and `view()` is that clock.** It
already accounts for the link's jitter, the playout delay and the prediction
lead. A render time derived from `performance.now()`, from a tick arrival, or
from a smoothing pass of your own is a second clock, and every judder bug
this layer has shipped was one. Record rings from the tick callbacks, never
from the render loop; interpolate between the bracketing frames; never
extrapolate a character past its last confirmed pose.

`Lockstep` options, beyond the ones above: `snapshotEvery` (default 100 ticks
for a serializable sim, 0 otherwise and in a match), `hashEvery`, `fps` (until
the node says), `reconnect`, `playout`, `catchup`, `anchored` (run as a match —
see [docs/match.md](https://github.com/m0dE/arrr-sdk/blob/main/docs/match.md)), `runtime`
(a `netcode.FakeRuntime` puts the whole layer under a fake clock in tests), and the callbacks `onTick`, `onCaughtUp`,
`onDesync`, `onSlack`, `onError`, `onConnected`, `onDisconnected`,
`onOverwhelmed`. `onDisconnected(info)` says why the connection went
(`{ code, reason, wasClean, byClient }`, see `DisconnectInfo`); the layer
redials on every loss whatever it says. `ls.roundTripMs` is this client's round
trip, `null` until the first echo - never 0, which would be a measurement -
and known to within one tick. `predict: true` requires `serialize`/`deserialize` and
`fingerprint`, and the constructor refuses a sim without them rather than
failing at the first rollback.

With `predict: true` the layer sends for you: `inputSource` is read on every
beat and the input goes out aimed at its frame. A client without prediction
(a bot, a spectator, a sim too heavy to clone) calls `ls.send(input)` itself,
or gives an `inputSource` without `predict` and lets the beat send it.
Everything sent that is not a lifecycle message reaches `sim.applyInput` on
every client — a ping report or a chat line down the same connection is an
input. Tag gameplay payloads and have the sim ignore the rest.

### In a Worker

A sim the size of a game server does not run on the render thread. Host the
whole `Lockstep` in a Worker and draw from a `lockstep.RenderView` on the main
thread: the worker posts, per confirmed tick, `{ frame, clock: ls.clock.snapshot(),
catchingUp: ls.catchup.active, at: ls.rt.now() }` and, per predicted step,
`{ frame, beatAt: ls.prediction!.beatAt, beatPeriod: ls.prediction!.period, beatInterval: ls.prediction!.beatInterval }`; the main thread
hands those to `rv.confirmed()` / `rv.predicted()`, calls
`rv.timeBase(worker.performance.timeOrigin - main.performance.timeOrigin)`
once, and reads `rv.view()` per frame exactly as it would `ls.view()` —
`renderTimes` takes either. Forward `onDisconnected` to `rv.predictionStopped()`
and a re-seed to `rv.reset()`, or the main thread keeps drawing from a
prediction that no longer exists. Do not post the worker's drawn clock and
extrapolate it between posts.

### Reading the numbers

`ls.view()` carries `delayMs` (the measured gap between the node's clock and
what you are drawing) and `starved` (the picture ran out of confirmed world).
`ls.report()` carries the rest: `clock` (`oneWayMs`, `period`, `echoes`, and
`slack` — the node's own report of how early each input arrived; `missed`
must be 0), `playout`, `prediction` (`lead`, `marginMs`, `rollbacks`,
`mispredictions`, and `misses` with both fingerprints per misprediction, so
the divergent field is read rather than guessed), `desync` (`verdicts`
against `noVerdict` — a room too small for a majority proves nothing about
agreement), `snapshots` and `catchup`.

Every convergence constant in the clock is denominated in echoes, and an echo
is one of your own inputs confirmed: a game that idles slowly learns the link
slowly. Send an input every beat, idle or not.

### Matches

A lockstep peer cannot skip history, so a persistent room's join cost grows
with its stream (snapshots bound it). A match has no such problem: a lobby
gathers, a `begin` in the ordered stream is frame zero for everybody, and
nobody joins after it. `match.Matchmaker` finds or mints the room and hands
the held connection to `Lockstep({ anchored })`. See
[docs/match.md](https://github.com/m0dE/arrr-sdk/blob/main/docs/match.md).

## NPCs

Characters that talk, owned by your app. Your server trades the app's API key for a
ticket (`POST /api/apps/:appId/npcs/:slug/token` with `{ playerId }`), and the browser
opens the call with it:

```js
import { NpcCall } from 'arrr-network';

const call = new NpcCall({ tokenUrl: '/api/npc-ticket' }); // your endpoint that returns the ticket JSON
await call.start();                                         // mic on, conversation live
call.on('heard', h => show('you', h.text));                 // what the NPC understood
call.on('delta', t => append(t));                           // the reply as it is written
call.on('reply', r => done(r.stats));                       // hear/think/speak timings
call.say('typed text works too');
call.interrupt();                                           // abandon the reply in progress
call.stop();
```

The client handles the microphone, end-of-utterance detection, barge-in (ducks the
NPC, hands over when the new reply's audio arrives) and playback on the audio clock.
Pass `ticket: <the JSON>` instead of `tokenUrl` if you already hold one. A script-tag
build is at `https://cloud.arrr.fun/npc/arrr-npc.js` (global `arrrNpc`). Guide:
https://arrr.fun/npcs

## Identity and the vault

Sign in a player with one ARRR account, then read and write their save data on
the mesh - built so that no node, and not even central on its own, can read
what a player saved:

```js
const session = await arrrNetwork.identity.login({ appId: 'your-app-id' });   // opens the ARRR sign-in popup on cloud.arrr.fun
arrrNetwork.identity.current({ appId })   // session or null, restored from localStorage
arrrNetwork.identity.logout({ appId })
arrrNetwork.identity.onChange(session => { /* signed in, out, or in another tab */ })
// session: { userId, username, pub, token, expiresAt, appId, recId, dataKey, delegate, holders, centralServiceUrl }

const store = arrrNetwork.vault.open(session);
const doc = await store.load();          // {} the first time
store.set('gold', 5); store.get('gold'); store.remove('gold');
await store.save();                       // quorum write to the player's holder nodes; retries once on a lost race, then throws VaultConflict - store.onConflict(cb) to merge first
                                          // a save with no changes still writes a new version; overlapping saves run one after another

const room = await arrrNetwork.connect(roomId, {
  appId, identity: session, save: doc,
  onConnect() { /* ... */ },
  onTick(frame, inputs) {
    for (const input of inputs) {
      if (input.data && input.data.arrrSave) applySave(input.clientId, input.data.arrrSave);
      else apply(input.clientId, input.data);
    }
  }
});
```

Passing `identity` to `connect()` makes the node stamp the connecting client's
`userId` from the session; passing `save` sends the document as that player's
first input right after `onConnect`, wrapped as `{ arrrSave: doc }` so a game
recognises it by that key rather than by its position in the stream. It
arrives at a definite frame like any other input, so every peer - including a
late joiner reading it off the snapshot - applies it at the same frame.

The page must be served over https (or from localhost): browsers provide
WebCrypto, which the vault is built on, only to a secure origin. The sign-in
popup keeps the player's keys in its own origin's IndexedDB when "stay signed
in" is on, so the next `login()` posts a session back without a password;
the player signs out of the popup itself - forgetting the keys on that
browser - at `/id/#/account` on central. If the browser blocks the popup,
`login()` navigates to the sign-in page with a `return=` and a one-time
`state`, and `identity.current()` picks the session up from the URL on the
way back only when the state matches the login this tab started.
`session.token` is scoped to the app it was issued for: it joins that app's
rooms and reads the player's holders, and cannot change the account, join
another app's rooms as the player, or open the console. Which sites may sign
players in is the app's **Allowed origins** list in the console: any other
site is refused by the page, and an empty list makes the page ask the player
to confirm the site by name. `identity.crypto` exposes the crypto core
(records, delegation, Shamir shares, canonical JSON) for pages that need it
directly.

A record is at most 256 KiB on the wire, which fits roughly 190 KiB of JSON
(the document is padded to 1 KiB buckets before encryption, so even a node
watching sizes learns little). Signing in with a password is the strongest
tier: only the player can ever decrypt their data. Signing in with OAuth, or
resetting a password by email, is one notch weaker: central and k holder
nodes would have to collude to do the same - so k is a collusion bound as
much as an availability one. A node never sees more than an opaque user id,
opaque record ids, sizes, times and the client's IP - never a username, an
email, which game a record belongs to, or a byte of the save.

### What survives a node going away

Each record is placed on **n** holders and every one of them keeps a *whole*
copy, signed by the player's own key. A signature is checked against that
key, not against the other holders, so a record is self-verifying and one
honest copy is enough to read: the SDK asks the nearest holder and trusts its
answer only if the signature verifies, falling back to a fan-out when the
answer is missing, stale or forged. A write is done when **k** holders have
acknowledged it. The Shamir share behind OAuth and email reset is the one
thing split rather than copied, and reassembling it also takes **k**.

So, with n holders and threshold k:

| Holders still up | Saves readable | New saves, OAuth sign-in |
|---|---|---|
| n .. k | yes | yes |
| k-1 .. 1 | yes | no, until repair finishes |
| 0 | no | no |

Central's repair sweep notices a holder that has stopped answering and copies
the record onto a fresh one from any survivor, so the degraded row above is a
window, not a resting state - and a replacement is chosen on a machine none
of the surviving copies is already on.

That last part is the thing that makes the table mean anything: holders are
picked one per **owner** while there are owners to go round, so "3 holders
gone" means three separate machines, not one box that was quietly running
three of them. The public network runs **n=5, k=2** across five independently
owned machines: any three can vanish at once and every player's data is both
safe and still writable.

Raising n without raising k buys loss tolerance and spends collusion
resistance, since k is both. Five and two is the setting for a five-machine
mesh; a much larger one should raise k with it.

A backend can read a player's record with the app's own key (minted once in
the console; the private key is shown exactly once and never stored by ARRR),
rather than the player's:

```js
import { decryptRecord, fetchPlayerRecord } from 'arrr-network/server';

// userId and recId come from the game page's session (session.userId, session.recId):
// record ids are blinded, so central cannot compute them for you.
const record = await fetchPlayerRecord({ centralServiceUrl, apiKey, appId, userId, recId });   // null when there is no save yet
const doc = await decryptRecord(appPrivateKey, record);
```

`fetchPlayerRecord` calls `GET /api/apps/:appId/players/:userId/record?recId=`
with the app's API key as `x-api-key`, and verifies the player's signature
(central hands back the account's public key alongside) before returning the
record; `decryptRecord` then opens the copy of the content key that was sealed
to the app's data key. A record written before the app minted its data key
has no such copy and will not open.

Because a save is written and signed by the player's own client, a cheater
can edit their own save today - a node checks the signature and the size, not
whether the contents are plausible. **Witnessed writes** (co-signatures from
other players in the same room, over the exact state being saved) close that
gap and are designed but not shipped yet. Guides: https://arrr.fun/identity
and https://arrr.fun/player-data

## Requirements

Node.js 20 or newer, or any browser with `WebSocket`. In Node the SDK uses `ws`;
in browsers that dependency is stubbed out in favour of the platform
`WebSocket`. The identity and vault parts are built on WebCrypto
(`globalThis.crypto.subtle`), which Node has as a global since 20; on Node 18
the package still imports and rooms still work, but the first identity call
throws a plain error saying WebCrypto is missing.

## License

MIT
